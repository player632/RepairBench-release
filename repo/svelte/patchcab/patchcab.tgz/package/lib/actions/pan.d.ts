import type { Action } from '../types';
export declare type OnPan = (value: {
    x: number;
    y: number;
    dx?: number;
    dy?: number;
}) => void;
/**
 * Element pan event
 *
 * @example
 *
 * <div use:usePan={onPan} />
 *
 * @category Actions
 */
declare const usePan: Action<OnPan>;
export default usePan;
