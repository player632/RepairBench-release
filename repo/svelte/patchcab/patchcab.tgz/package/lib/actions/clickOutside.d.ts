import type { Action } from '../types';
export declare type OnClickOutside = (e: MouseEvent) => void;
/**
 * Detect a click outside of the target element or it's children
 *
 * @example
 *
 * <div use:useClickOutside={oClickOutside} />
 *
 * @category Actions
 */
declare const useClickOutside: Action<OnClickOutside>;
export default useClickOutside;
