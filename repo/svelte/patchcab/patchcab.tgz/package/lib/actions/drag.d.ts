import type { Action } from '../types';
export declare type OnDrag = (x: number, y: number, box: DOMRect) => void;
/**
 * Element drag event
 *
 * @example
 *
 * <div use:onDrag={dragCallback} />
 *
 * @category Actions
 */
declare const useDrag: Action<OnDrag>;
export default useDrag;
