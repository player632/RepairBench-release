import type Point from './Point';
/**
 * Get an SVG quadratic bézier curve path based simulating a catenary curve
 * @param p1 - Line Start point
 * @param p2 - Line End point
 *
 * @category Helpers
 */
export declare const getCatenaryPath: (p1: Point, p2: Point) => string;
