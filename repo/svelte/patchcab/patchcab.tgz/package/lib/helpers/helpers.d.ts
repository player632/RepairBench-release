/**
 * Transform a value between two ranges
 * @param value - Current value
 * @param from - [min, max] current value range
 * @param to -  [min, max] target value range
 * @param precision - scaled value decimal places precision
 *
 * @example
 * // scale a value
 * const scaledValue = scale(originalValue, [0, 100], [25, 50], 2);
 *
 * @category Helpers
 */
export declare const scale: (value: number, from: [number, number], to: [number, number], precision?: number) => number;
/**
 * Round a number with specific decimal places precision
 *
 * @example
 * const freq = round(420.240);
 *
 * @category Helpers
 */
export declare const round: (value: number, precision?: number) => number;
/**
 * Check if a keyboard event can be intercepted as a shortcut
 *
 * @example
 * // skip processing a keyboard event if definately not a shortcut
 * const onKeyDown = (e: KeyboardEvent) => {
 *    if(!isShortcut()){
 *        return true;
 *    }
 * }
 *
 * @category Helpers
 */
export declare const isShortcut: (e: KeyboardEvent) => boolean;
/**
 * Retruns a random color hex code from a predefined list
 *
 * @example
 * const color = randomColor()
 *
 * @category Helpers
 */
export declare const randomColor: () => string;
/**
 * Convert module title name to a safe file name
 *
 * @example
 * const fileName = safeName(input);
 *
 * @category Helpers
 */
export declare const safeName: (name: string) => string;
