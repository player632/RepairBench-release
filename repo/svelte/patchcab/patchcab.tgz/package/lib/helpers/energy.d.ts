import type { Analyser } from 'tone';
/**
 * Frequency
 */
declare type FrequencyRange = 'low' | 'mid' | 'high';
declare const getEnergy: (analyser: Analyser, low: FrequencyRange, high?: FrequencyRange) => number;
export default getEnergy;
