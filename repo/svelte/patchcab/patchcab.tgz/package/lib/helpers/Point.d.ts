/**
 * Define a point in 2D space
 *
 * @example
 * // Create a point
 * const pointA = new Point(0, 0);
 * // Update point positions
 * pointA.update(10, 10)
 * // Get a distance to another point
 * const distance = pointA.getDistanceTo(pointB);
 *
 * @category Helpers
 */
declare class Point {
    x: number;
    y: number;
    constructor(x: number, y: number);
    /**
     * Update the x and y values
     */
    update(point: Point): void;
    /**
     * Get the difference for x and y axis to another point
     */
    getDifferenceTo(point: Point): Point;
    /**
     * Calculate distance to another point
     */
    getDistanceTo(point: Point): number;
}
export default Point;
