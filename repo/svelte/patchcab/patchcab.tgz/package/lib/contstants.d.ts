export declare const HP: {
    w: number;
    h: number;
};
export declare const BAR_HEIGHT = 48;
