import type { ToneAudioNode } from 'tone';
import type Bang from './nodes/Bang';
export type { default as Bang } from './nodes/Bang';
/**
 * Library
 */
export declare type LibraryItem = {
    set: string;
    name: string;
    tags: string[];
    size: {
        w: number;
        h: number;
    };
    author: {
        name: string;
        url?: string;
    };
    libs: string[];
};
export declare type Library = LibraryItem[];
/**
 * Modules
 */
export declare type Module = {
    id?: string;
    type: string;
    position?: {
        x: number;
        y: number;
    };
    size: {
        w: number;
        h: number;
    };
    libs: string[];
    state?: State;
};
export declare type State = {
    [key: string]: number | string | Array<number | string>;
};
export declare type ModuleState = {
    id?: string;
    state: State;
    position: {
        x: number;
        y: number;
    };
};
/**
 * Patch
 */
export declare type PatchInput = Bang | ToneAudioNode;
export declare type PatchOutput = Bang | ToneAudioNode;
export declare type Patch = {
    input: string;
    output: string;
    node: PatchInput;
    color?: string;
    selected?: string;
};
/**
 * Action
 */
interface ActionResult<P> {
    update?: (parameters?: P) => void;
    destroy?: () => void;
}
export declare type Action<P> = (node: Element, parameters?: P) => ActionResult<P>;
/**
 * State
 */
export declare type Rack = {
    title?: string;
    modules: Module[];
    patches: Patch[];
};
/**
 * App view
 */
export declare type View = 'shelf' | 'rack' | 'help';
/**
 * Connection
 */
export declare type Connection = {
    id: string;
    node: PatchInput | PatchOutput;
};
/**
 * User
 */
export declare type User = {
    username: string;
};
