declare type BangCallback = (time: number, attack: boolean, release: boolean) => void;
declare class Bang {
    private bangs;
    private output;
    constructor(output?: BangCallback);
    connect(bang: Bang): void;
    disconnect(bang: Bang): void;
    bang(time: number, attack?: boolean, release?: boolean): void;
    trigger(time: number, attack?: boolean, release?: boolean): void;
}
export default Bang;
